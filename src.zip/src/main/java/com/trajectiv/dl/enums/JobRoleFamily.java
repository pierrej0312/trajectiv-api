package com.trajectiv.dl.enums;

public enum JobRoleFamily {
    SOFTWARE_ENGINEERING,
    PRODUCT_DESIGN,
    DATA,
    DEVOPS_CLOUD,
    PROJECT_MANAGEMENT,
    PRODUCT_MANAGEMENT,
    QUALITY_ASSURANCE,
    BUSINESS_ANALYSIS,
    OTHER
}
